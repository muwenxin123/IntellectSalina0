﻿#include "IAgriVideoPlayerDJIDialog.h"
#include "ui_IAgriVideoPlayerDJIDialog.h"
#include <QDebug>
IAgriVideoPlayerDJIDialog::IAgriVideoPlayerDJIDialog(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::IAgriVideoPlayerDJIDialog)
	, videoThread(new VideoThreadDJI(this))
{
    ui->setupUi(this);
}

IAgriVideoPlayerDJIDialog::~IAgriVideoPlayerDJIDialog()
{
    delete ui;
}

void IAgriVideoPlayerDJIDialog::Init()
{
	//std::string strURl = "rtmp://192.168.1.115/live/1581F6Q8D246C00GV99U-81-0-0";
	std::string strURl = "D:\\work\\IntellectSalina_GDD\\bin\\TestFire.mp4";

	ui->label->setAlignment(Qt::AlignCenter);
	ui->label->setText("...");

	// 设置子线程信号
	connect(videoThread, &VideoThreadDJI::newFrame, this, &IAgriVideoPlayerDJIDialog::onNewFrame);

	// 启动线程并设置 RTMP 地址
	videoThread->setRtmpUrl(strURl.c_str()); 
	videoThread->start();
}

void IAgriVideoPlayerDJIDialog::updateFrame()
{

}

void IAgriVideoPlayerDJIDialog::onNewFrame(const QImage &frame)
{
	if (!frame.isNull()) {
		ui->label->setPixmap(QPixmap::fromImage(frame).scaled(
			ui->label->size(), Qt::KeepAspectRatio, Qt::SmoothTransformation));
	}
}

VideoThreadDJI::VideoThreadDJI(QObject *parent) : QThread(parent) {}

VideoThreadDJI::~VideoThreadDJI()
{
	requestInterruption();
	wait();

	if (formatCtx) avformat_close_input(&formatCtx);
	if (packet) av_packet_free(&packet);
	if (frame) av_frame_free(&frame);
	if (frameRGB) av_frame_free(&frameRGB);
	if (buffer) av_free(buffer);
	if (swsCtx) sws_freeContext(swsCtx);
	avformat_network_deinit();
}

void VideoThreadDJI::setRtmpUrl(const QString &url)
{
	rtmpUrl = url;
}

void VideoThreadDJI::run()
{
	avformat_network_init();

	formatCtx = avformat_alloc_context();
	AVDictionary *opts = nullptr;
	av_dict_set(&opts, "rtmp_transport", "tcp", 0);
	av_dict_set(&opts, "stimeout", "5000000", 0); // 5s timeout

	if (avformat_open_input(&formatCtx, rtmpUrl.toStdString().c_str(), nullptr, &opts) != 0) {
		qDebug() << "❌ 无法打开 RTMP 流:" << rtmpUrl;
		av_dict_free(&opts);
		return;
	}
	av_dict_free(&opts);

	if (avformat_find_stream_info(formatCtx, nullptr) < 0) {
		qDebug() << "❌ 无法获取流信息";
		return;
	}

	// 查找视频流
	videoStreamIndex = -1;
	for (unsigned int i = 0; i < formatCtx->nb_streams; i++) {
		if (formatCtx->streams[i]->codecpar->codec_type == AVMEDIA_TYPE_VIDEO) {
			videoStreamIndex = i;
			break;
		}
	}

	if (videoStreamIndex == -1) {
		qDebug() << "❌ 未找到视频流";
		return;
	}

	// 获取解码器
	AVCodecParameters *codecPar = formatCtx->streams[videoStreamIndex]->codecpar;
	AVCodec *codec = avcodec_find_decoder(codecPar->codec_id);
	if (!codec) {
		qDebug() << "❌ 未找到解码器";
		return;
	}

	codecCtx = avcodec_alloc_context3(codec);
	avcodec_parameters_to_context(codecCtx, codecPar);
	if (avcodec_open2(codecCtx, codec, nullptr) < 0) {
		qDebug() << "❌ 无法打开解码器";
		return;
	}

	width = codecCtx->width;
	height = codecCtx->height;

	// 准备帧
	frame = av_frame_alloc();
	frameRGB = av_frame_alloc();
	packet = av_packet_alloc();

	int bufferSize = av_image_get_buffer_size(AV_PIX_FMT_RGB24, width, height, 1);
	buffer = (uint8_t *)av_malloc(bufferSize);
	av_image_fill_arrays(frameRGB->data, frameRGB->linesize, buffer, AV_PIX_FMT_RGB24, width, height, 1);

	// YUV -> RGB 转换器
	swsCtx = sws_getContext(width, height, codecCtx->pix_fmt,
		width, height, AV_PIX_FMT_RGB24,
		SWS_BILINEAR, nullptr, nullptr, nullptr);

	// 循环拉流、解码、发送图像
	while (!isInterruptionRequested()) {
		if (av_read_frame(formatCtx, packet) >= 0) {
			if (packet->stream_index == videoStreamIndex) {
				if (avcodec_send_packet(codecCtx, packet) == 0) {
					while (avcodec_receive_frame(codecCtx, frame) == 0) {
						// 转换为 RGB
						sws_scale(swsCtx,
							(uint8_t const* const*)frame->data,
							frame->linesize,
							0, height,
							frameRGB->data,
							frameRGB->linesize);

						// 生成 QImage
						QImage img(frameRGB->data[0], width, height, frameRGB->linesize[0], QImage::Format_RGB888);
						emit newFrame(img.copy()); // 注意：拷贝一份，避免跨线程问题

						av_packet_unref(packet);
						msleep(30);
						break; // 只解码一帧，下一轮再解码下一帧
					}
				}
			}
			av_packet_unref(packet);
		}
		else {
			msleep(30); // 没数据时短暂休眠
		}
	}
}