#ifndef IAGRIVIDEOPLAYERDJIDIALOG_H
#define IAGRIVIDEOPLAYERDJIDIALOG_H

#include <QWidget>
extern "C"
{
#include <libavcodec/avcodec.h>
#include <libavformat/avformat.h>
#include <libswscale/swscale.h>
#include <libavdevice/avdevice.h>
#include <libavutil/avutil.h>
#include "libavutil/imgutils.h"
#include <libavutil/time.h>
}
#define OPENCV
//#include "darknet/include/yolo_v2_class.hpp"
#include <opencv2/opencv.hpp>
#include <iostream>
#include <sstream>
#include <map>
#include <direct.h>
#include <io.h>

#include <QLabel>

#include <QTimer>

#include <QThread>
#include<QMutexLocker>
#include <QMutex>


#ifndef VIDEOTHREADDJI_H
#define VIDEOTHREADDJI_H
#include <QImage>

class VideoThreadDJI : public QThread
{
	Q_OBJECT

public:
	explicit VideoThreadDJI(QObject *parent = nullptr);
	~VideoThreadDJI();

	void setRtmpUrl(const QString &url);
	void run() override;

signals:
	void newFrame(const QImage &frame);  // ���ͽ�����ͼ�����߳�

private:
	QString rtmpUrl;
	AVFormatContext *formatCtx = nullptr;
	AVCodecContext *codecCtx = nullptr;
	AVFrame *frame = nullptr;
	AVFrame *frameRGB = nullptr;
	AVPacket *packet = nullptr;
	SwsContext *swsCtx = nullptr;
	int videoStreamIndex = -1;
	uint8_t *buffer = nullptr;
	int width = 0, height = 0;
};

#endif // VIDEOTHREAD_H


namespace Ui {
class IAgriVideoPlayerDJIDialog;
}

class IAgriVideoPlayerDJIDialog : public QWidget
{
    Q_OBJECT

public:
    explicit IAgriVideoPlayerDJIDialog(QWidget *parent = nullptr);
    ~IAgriVideoPlayerDJIDialog();

	void Init();

	VideoThreadDJI *videoThread;

	private slots:

	void onNewFrame(const QImage &frame);
	void updateFrame();
private:
    Ui::IAgriVideoPlayerDJIDialog *ui;
};

#endif // IAGRIVIDEOPLAYERDJIDIALOG_H
